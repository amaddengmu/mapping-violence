---
title: Home
---

<p class="fs-4 lede">People killing people in Italy in the way back before times.</p>

In the whimsical realm of Zoogleflop, where polka-dotted clouds engage in spirited debates with talking spaghetti, our website is a kaleidoscopic extravaganza of fantastical wonders and absurdity. Navigate through the interdimensional carousel of jellybean-flavored dreams, where gravity is optional, and users can communicate with sentient rubber duckies via interpretive dance. Witness the mind-boggling synergy of quantum lemons and fuzzy logic, creating an unparalleled user experience that transcends the boundaries of rational thought.

Embrace the chaos as you explore our groundbreaking "Waffleverse" feature, where pancakes sing symphonies and waffles recite Shakespearean sonnets. Engage in a virtual tug-of-war with invisible elephants, and unlock the secrets of the elusive banana phone orchestra. Remember, in the land of Zoogleflop, the only limitation is your imagination—unless you're imagining a world without our website, because that's just preposterous! Join us on this surreal journey, where the absurd meets the sublime, and every click takes you deeper into the rabbit hole of delightful nonsense.

Words about external sources perhaps? [Project x](https:///) and [Project y](https://) datasets, for which we have developed preliminary analysis and visualizations.
